void parteD(int, int);
void pedidosHDD();
void memInfo();
void loadAvg();