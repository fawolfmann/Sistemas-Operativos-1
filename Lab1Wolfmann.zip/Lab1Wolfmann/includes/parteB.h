void parteB();
void printCPUData();
void printKernelV();
void printNumFileSysSuport();
void printUpTime();
void secToDayHourMinSec (float, char*);