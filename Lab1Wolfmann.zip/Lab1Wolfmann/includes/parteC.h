void parteC();
void cpuTimes();
void contextChanges();
void bootUpTime();
void processes();